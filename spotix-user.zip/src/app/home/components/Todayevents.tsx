"use client"

import React from "react"
import { Calendar, MapPin } from "lucide-react"

interface HomeEvent {
  eventId: string
  eventName: string
  venue: string
  eventType: string
  eventStartDate: string
  freeOrPaid: boolean
  eventImage: string
}

interface TodayEventsProps {
  events: HomeEvent[]
  loading: boolean
  onEventClick: (eventId: string) => void
}

const LazyImage: React.FC<{ src: string; alt: string; className?: string }> = ({ src, alt, className }) => {
  const [isLoaded, setIsLoaded] = React.useState(false)
  const [hasError, setHasError] = React.useState(false)

  const getOptimizedImageUrl = (url: string): string => {
    if (!url) return "/placeholder.svg"
    if (url.includes("cloudinary.com")) {
      const uploadIndex = url.indexOf("/upload/")
      if (uploadIndex !== -1) {
        const before = url.substring(0, uploadIndex + 8)
        const after = url.substring(uploadIndex + 8)
        return `${before}c_fill,w_800,h_600,q_auto,f_auto/${after}`
      }
    }
    return url
  }

  return (
    <div className={`relative ${className || ""}`}>
      {!isLoaded && !hasError && (
        <div className="absolute inset-0 bg-gradient-to-r from-gray-200 via-gray-300 to-gray-200 animate-pulse" />
      )}
      <img
        src={getOptimizedImageUrl(src)}
        alt={alt}
        onLoad={() => setIsLoaded(true)}
        onError={() => { setHasError(true); setIsLoaded(true) }}
        className={`w-full h-full object-cover transition-opacity duration-300 ${isLoaded ? "opacity-100" : "opacity-0"}`}
      />
      {hasError && (
        <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-purple-100 to-purple-50">
          <span className="text-4xl">🎉</span>
        </div>
      )}
    </div>
  )
}

const EventCardSkeleton: React.FC = () => (
  <div className="bg-white rounded-xl border-2 border-gray-200 overflow-hidden animate-pulse">
    <div className="h-48 bg-gray-200" />
    <div className="p-4 space-y-3">
      <div className="h-5 bg-gray-200 rounded w-3/4" />
      <div className="h-4 bg-gray-200 rounded w-1/2" />
      <div className="h-4 bg-gray-200 rounded w-2/3" />
    </div>
  </div>
)

const EventCard: React.FC<{ event: HomeEvent; onClick: () => void }> = ({ event, onClick }) => {
  return (
    <div
      onClick={onClick}
      className="group bg-white rounded-xl border-2 border-gray-200 overflow-hidden hover:border-purple-400 hover:shadow-2xl transition-all duration-300 cursor-pointer transform hover:scale-105"
    >
      <div className="relative h-48 overflow-hidden bg-gray-100">
        <LazyImage src={event.eventImage || "/placeholder.svg"} alt={event.eventName} className="w-full h-full" />

        <div className="absolute top-3 left-3 flex gap-2 flex-wrap">
          <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold text-white shadow-lg ${!event.freeOrPaid ? "bg-green-500" : "bg-blue-500"}`}>
            {!event.freeOrPaid ? "Free" : "Paid"}
          </span>
          <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-red-500 text-white shadow-lg animate-pulse">
            Today
          </span>
        </div>

        <div className="absolute top-3 right-3">
          <div className="bg-white rounded-lg shadow-lg p-2 text-center min-w-[60px]">
            <div className="text-xs font-semibold uppercase" style={{ color: "#6b2fa5" }}>
              {new Date(event.eventStartDate).toLocaleDateString("en-US", { month: "short" })}
            </div>
            <div className="text-2xl font-bold text-gray-900">{new Date(event.eventStartDate).getDate()}</div>
          </div>
        </div>
      </div>

      <div className="p-4">
        <h3 className="font-bold text-lg text-gray-900 group-hover:text-purple-700 transition-colors line-clamp-2 mb-3">
          {event.eventName}
        </h3>
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-sm text-gray-700">
            <div className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 bg-purple-50">
              <Calendar size={12} style={{ color: "#6b2fa5" }} />
            </div>
            <span className="truncate font-medium">{event.eventType}</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-700">
            <div className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 bg-purple-50">
              <MapPin size={12} style={{ color: "#6b2fa5" }} />
            </div>
            <span className="truncate font-medium">{event.venue}</span>
          </div>
        </div>
      </div>
    </div>
  )
}

const TodayEvents: React.FC<TodayEventsProps> = ({ events, loading, onEventClick }) => {
  if (events.length === 0 && !loading) return null

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
      <div className="flex items-center gap-3 mb-6 flex-wrap">
        <h2 className="text-2xl sm:text-3xl font-bold text-gray-900">Events Today</h2>
        <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-semibold bg-red-500 text-white animate-pulse shadow-md">
          Live
        </span>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
        {loading
          ? Array.from({ length: 4 }).map((_, i) => <EventCardSkeleton key={i} />)
          : events.map((event, index) => (
              <EventCard
                key={event.eventId || `today-${index}`}
                event={event}
                onClick={() => onEventClick(event.eventId)}
              />
            ))}
      </div>
    </section>
  )
}

export default TodayEvents