import { NextRequest, NextResponse } from "next/server";
import { adminDb } from "@/app/lib/firebase-admin";
import { FieldValue } from "firebase-admin/firestore";

/**
 * Atomic Operations API Route
 * Handles event statistics updates atomically
 * POST /api/v1/atomic
 *
 * Strictly deducts `quantity` from the matching ticketPrices[].availableTickets
 * (when set) and adds `quantity` to ticketPrices[].ticketsSold, plus the
 * top-level event ticketsSold — all in one atomic transaction, hence the name "atomic".
 */

interface AtomicOperationsRequest {
  creatorId: string;
  eventId: string;
  ticketType: string;          // must match ticketPrices[].policy exactly
  ticketPrice: number;
  quantity?: number;           // seats purchased for this ticket type
  discountCode?: string | null;
  ticketId: string;            // idempotency key (first ticketId of the batch)
}

interface TicketPriceEntry {
  policy: string;
  price: number;
  ticketsSold?: number;
  availableTickets?: number | null;
  [key: string]: any;
}

interface OperationsPerformed {
  ticketsSoldIncremented: boolean;
  revenueUpdated: boolean;
  availableTicketsDecremented: boolean;
  discountUpdated: boolean;
  organizerStatsUpdated: boolean;
}

export async function POST(req: NextRequest) {
  try {
    const body: AtomicOperationsRequest = await req.json();
    const { creatorId, eventId, ticketType, ticketPrice, quantity, discountCode, ticketId } = body;

    // Validate required fields 
    if (!creatorId || !eventId || !ticketType || ticketPrice === undefined || !ticketId) {
      return NextResponse.json(
        {
          error: "Bad Request",
          message: "Missing required fields: creatorId, eventId, ticketType, ticketPrice, ticketId",
        },
        { status: 400 }
      );
    }

    // qty is exactly what the user purchased of minimum 1
    const qty = Math.max(1, Number(quantity) || 1);

    console.log(`[Atomic] ticketId=${ticketId} | event=${eventId} | type="${ticketType}" | qty=${qty}`);

    const eventDocRef     = adminDb.collection("events").doc(eventId);
    const organizerDocRef = adminDb.collection("users").doc(creatorId);

    // Idempotency guard (outside transaction — cheap read) 
    const processedRef = eventDocRef.collection("_processedTickets").doc(ticketId);
    const processedDoc = await processedRef.get();

    if (processedDoc.exists) {
      console.log(`[Atomic] ${ticketId} already processed — skipping`);
      return NextResponse.json(
        { success: true, message: "Already processed (idempotent)", ticketId, alreadyProcessed: true },
        { status: 200 }
      );
    }

    const operationsPerformed: OperationsPerformed = {
      ticketsSoldIncremented: false,
      revenueUpdated: false,
      availableTicketsDecremented: false,
      discountUpdated: false,
      organizerStatsUpdated: false,
    };

    // Single Firestore transaction 
    await adminDb.runTransaction(async (tx) => {
      const eventDoc     = await tx.get(eventDocRef);
      const organizerDoc = await tx.get(organizerDocRef);

      if (!eventDoc.exists) {
        throw Object.assign(new Error(`Event not found: ${eventId}`), { statusCode: 404 });
      }

      const eventData = eventDoc.data()!;
      const ticketPrices: TicketPriceEntry[] = Array.isArray(eventData.ticketPrices)
        ? eventData.ticketPrices
        : [];

      // Find the matching tier 
      const tierIndex = ticketPrices.findIndex((t) => t.policy === ticketType);

      if (tierIndex === -1) {
        // Type not found in ticketPrices — log and continue without array update
        // (event may not have typed tiers; top-level count still increments)
        console.warn(`[Atomic] Ticket type "${ticketType}" not found in ticketPrices — skipping tier update`);
      }

      // Build the updated ticketPrices array 
      let availableTicketsDecremented = false;
      const updatedTicketPrices = ticketPrices.map((tier, i) => {
        if (i !== tierIndex) return tier; // leave every other tier untouched

        // ticketsSold: treat missing/undefined as 0
        const currentSold = Number(tier.ticketsSold) || 0;

        // availableTickets: only present when the organizer set a limit
        const hasLimit =
          tier.availableTickets !== null &&
          tier.availableTickets !== undefined;

        if (hasLimit) {
          const currentAvailable = Number(tier.availableTickets);

          // Hard guard — reject the whole transaction if for any reason we are overselling
          if (currentAvailable < qty) {
            throw Object.assign(
              new Error(
                currentAvailable === 0
                  ? `Ticket type "${ticketType}" is sold out.`
                  : `Only ${currentAvailable} ticket(s) left for "${ticketType}". Requested: ${qty}.`
              ),
              { statusCode: 409 }
            );
          }

          availableTicketsDecremented = true;
          return {
            ...tier,
            ticketsSold: currentSold + qty,           // +qty to this tier's sold count
            availableTickets: currentAvailable - qty,  // −qty from this tier's available count
          };
        }

        // No limit set — only increment ticketsSold
        return {
          ...tier,
          ticketsSold: currentSold + qty,
        };
      });

      operationsPerformed.availableTicketsDecremented = availableTicketsDecremented;

      // Write event document 
      // ticketsSold (top-level) uses FieldValue.increment so concurrent
      // transactions don't race on that scalar field.
      // ticketPrices array is written back in full (Firestore has no
      // per-element array increment — this is the correct pattern).
      tx.update(eventDocRef, {
        ticketsSold:  FieldValue.increment(qty),
        totalRevenue: FieldValue.increment(Number(ticketPrice) * qty),
        ...(tierIndex !== -1 ? { ticketPrices: updatedTicketPrices } : {}),
      });

      operationsPerformed.ticketsSoldIncremented = true;
      operationsPerformed.revenueUpdated         = true;

      // Write organizer document 
      if (organizerDoc.exists) {
        tx.update(organizerDocRef, {
          totalTicketsSold: FieldValue.increment(qty),
          totalRevenue:     FieldValue.increment(Number(ticketPrice) * qty),
        });
        operationsPerformed.organizerStatsUpdated = true;
      } else {
        console.warn(`[Atomic] Organizer doc not found for ${creatorId} — skipping user stats`);
      }

      // Mark processed (idempotency record) 
      tx.set(processedRef, {
        ticketId,
        ticketType,
        ticketPrice:  Number(ticketPrice),
        quantity:     qty,
        processedAt:  FieldValue.serverTimestamp(),
        createdAt:    new Date().toISOString(),
      });

      console.log(`[Atomic] Transaction committed — type="${ticketType}", qty=${qty}, availDecremented=${availableTicketsDecremented}`);
    });

    // Discount usage (non-blocking, outside transaction) 
    if (discountCode) {
      try {
        const discountDocRef = adminDb
          .collection("events")
          .doc(eventId)
          .collection("discounts")
          .doc(discountCode);

        const discountDoc = await discountDocRef.get();
        if (discountDoc.exists) {
          await discountDocRef.update({ usedCount: FieldValue.increment(qty) });
          operationsPerformed.discountUpdated = true;
          console.log(`[Atomic] Discount "${discountCode}" usedCount +${qty}`);
        }
      } catch (discountError) {
        console.error("[Atomic] Discount update error (non-blocking):", discountError);
      }
    }

    return NextResponse.json(
      {
        success: true,
        message: "Atomic operations completed successfully",
        ticketId,
        eventId,
        quantity: qty,
        operationsPerformed,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("[Atomic] Error:", error);
    const statusCode = (error as any)?.statusCode ?? 500;
    return NextResponse.json(
      {
        error: statusCode === 409 ? "Conflict" : statusCode === 404 ? "Not Found" : "Internal Server Error",
        message: error instanceof Error ? error.message : "Failed to perform atomic operations",
      },
      { status: statusCode }
    );
  }
}

// export async function GET() {
//   return NextResponse.json(
//     { status: "healthy", service: "Atomic Operations API", timestamp: new Date().toISOString() },
//     { status: 200 }
//   );
// }